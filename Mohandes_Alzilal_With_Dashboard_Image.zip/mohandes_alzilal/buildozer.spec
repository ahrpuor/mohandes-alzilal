[app]
title = Mohandes Alzilal
package.name = mohandesalzilal
package.domain = org.shadowlab
source.dir = .
source.include_exts = py,png,jpg,kv,atlas
version = 0.1.0
requirements = python3,kivy,openssl
orientation = portrait
fullscreen = 0
android.permissions = INTERNET, ACCESS_NETWORK_STATE
android.api = 35
android.minapi = 23
android.archs = arm64-v8a
android.allow_backup = False
# Buildozer يضبط بقية الخيارات الافتراضية عند البناء.

[buildozer]
log_level = 2
warn_on_root = 1
