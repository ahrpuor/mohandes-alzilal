# -*- coding: utf-8 -*-
"""
مهندس الظل — نموذج تعليمي أولي بواجهة Kivy.
الأدوات هنا محلية وآمنة: فحص اتصال الإنترنت، اختبار DNS لموقع يكتبه المستخدم،
وفحص استجابة HTTP لموقع يملكه أو لديه إذن بفحصه.
"""
import socket
import threading
from urllib.parse import urlparse
from urllib.request import Request, urlopen
from urllib.error import URLError, HTTPError

from kivy.app import App
from kivy.clock import Clock
from kivy.core.window import Window
from kivy.metrics import dp
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.textinput import TextInput
from kivy.uix.scrollview import ScrollView
from kivy.uix.popup import Popup

BG = (0.025, 0.04, 0.035, 1)
PANEL = (0.055, 0.085, 0.07, 1)
GREEN = (0.15, 0.95, 0.45, 1)
WHITE = (0.9, 0.96, 0.92, 1)
MUTED = (0.58, 0.72, 0.63, 1)

def make_label(text, size=16, color=WHITE, height=None, bold=False):
    return Label(text=text, size_hint_y=None, height=dp(height or 42),
                 color=color, font_size=dp(size), bold=bold,
                 halign="right", valign="middle", text_size=(Window.width-dp(44), None))

class ShadowApp(App):
    title = "مهندس الظل"

    def build(self):
        Window.clearcolor = BG
        root = BoxLayout(orientation="vertical", padding=dp(14), spacing=dp(10))
        header = BoxLayout(orientation="vertical", size_hint_y=None, height=dp(100), spacing=dp(3))
        header.add_widget(make_label("◈ مهندس الظل", 27, GREEN, 48, True))
        header.add_widget(make_label("مختبر تعليمي لأمن الشبكات والويب", 14, MUTED, 32))
        root.add_widget(header)

        self.status = make_label("الحالة: جاهز — استخدم الأدوات على أنظمة تملكها أو لديك إذن بفحصها.", 13, MUTED, 55)
        root.add_widget(self.status)

        scroll = ScrollView()
        body = BoxLayout(orientation="vertical", spacing=dp(10), size_hint_y=None)
        body.bind(minimum_height=body.setter("height"))

        body.add_widget(self.section_title("1) فحص الاتصال"))
        body.add_widget(self.make_button("اختبار اتصال الإنترنت", self.check_internet))
        body.add_widget(self.section_title("2) فحص DNS"))
        self.host_input = TextInput(
            hint_text="اكتب اسم نطاق تملكه، مثل example.com",
            multiline=False, size_hint_y=None, height=dp(48),
            background_color=PANEL, foreground_color=GREEN,
            hint_text_color=MUTED, cursor_color=GREEN, padding=dp(10))
        body.add_widget(self.host_input)
        body.add_widget(self.make_button("حلّ اسم النطاق (DNS)", self.check_dns))
        body.add_widget(self.section_title("3) فحص استجابة موقع"))
        body.add_widget(make_label("أدخل نطاقاً عاماً أو موقعاً لديك إذن بفحصه. هذا الاختبار يقرأ رمز الاستجابة فقط.", 13, MUTED, 50))
        body.add_widget(self.make_button("اختبار HTTPS / HTTP", self.check_http))
        body.add_widget(self.section_title("4) تعلّم بسرعة"))
        body.add_widget(self.make_button("ما هو DNS؟", lambda *_: self.info("DNS يحوّل اسم النطاق مثل example.com إلى عنوان IP يستطيع الجهاز الاتصال به.")))
        body.add_widget(self.make_button("ما هو HTTPS؟", lambda *_: self.info("HTTPS يشفّر الاتصال بين المتصفح والموقع باستخدام TLS، ويساعد على حماية البيانات أثناء النقل.")))
        body.add_widget(self.make_button("قواعد الفحص المسؤول", lambda *_: self.info("افحص أجهزتك ومواقعك فقط أو احصل على إذن واضح. لا تحاول تجاوز تسجيل الدخول أو تعطيل الخدمات أو جمع بيانات الآخرين.")))
        body.add_widget(self.make_button("مسح النتائج", self.clear_results))
        self.results = Label(text="النتائج ستظهر هنا.", color=WHITE, font_size=dp(14),
                             size_hint_y=None, height=dp(180), halign="right",
                             valign="top", text_size=(Window.width-dp(54), None))
        body.add_widget(self.results)
        scroll.add_widget(body)
        root.add_widget(scroll)
        return root

    def section_title(self, text):
        return make_label(text, 17, GREEN, 38, True)

    def make_button(self, text, callback):
        btn = Button(text=text, size_hint_y=None, height=dp(48),
                     background_normal="", background_color=PANEL,
                     color=GREEN, font_size=dp(15))
        btn.bind(on_release=callback)
        return btn

    def set_result(self, message):
        self.results.text = message
        self.status.text = "الحالة: اكتمل الاختبار"

    def run_bg(self, task):
        self.status.text = "الحالة: جارٍ الفحص..."
        def worker():
            try:
                message = task()
            except Exception as e:
                message = "تعذر إكمال الاختبار: " + str(e)
            Clock.schedule_once(lambda _dt: self.set_result(message), 0)
        threading.Thread(target=worker, daemon=True).start()

    def check_internet(self, *_):
        def task():
            try:
                socket.create_connection(("1.1.1.1", 443), timeout=4).close()
                return "نجح الاتصال بعنوان عام على المنفذ 443.\nهذا اختبار اتصال بسيط وليس تقييماً كاملاً لأمان الشبكة."
            except OSError:
                return "لم ينجح الاتصال. تحقق من الإنترنت أو إعدادات الشبكة."
        self.run_bg(task)

    def get_host(self):
        host = self.host_input.text.strip()
        if "://" in host:
            host = urlparse(host).hostname or ""
        host = host.split("/")[0].strip()
        if not host or any(ch.isspace() for ch in host):
            self.info("اكتب اسم نطاق صحيحاً، مثل example.com")
            return None
        return host

    def check_dns(self, *_):
        host = self.get_host()
        if not host:
            return
        def task():
            records = socket.getaddrinfo(host, None)
            ips = sorted({r[4][0] for r in records})
            return f"نتيجة DNS للنطاق: {host}\nالعناوين التي أعادها النظام:\n" + "\n".join(ips)
        self.run_bg(task)

    def check_http(self, *_):
        host = self.get_host()
        if not host:
            return
        def task():
            url = "https://" + host
            req = Request(url, method="GET", headers={"User-Agent": "ShadowLab-Educational/1.0"})
            try:
                with urlopen(req, timeout=6) as response:
                    return f"الموقع: {url}\nرمز الاستجابة: {response.status}\nنوع المحتوى: {response.headers.get('Content-Type', 'غير معروف')}\nهذا فحص استجابة أساسي فقط."
            except HTTPError as e:
                return f"الموقع: {url}\nرمز الاستجابة: {e.code}\nوصل رد HTTP، لكن الطلب لم يُقبل كاستجابة ناجحة."
            except URLError as e:
                return f"تعذر الوصول عبر HTTPS: {e.reason}\nتحقق من النطاق والاتصال."
        self.run_bg(task)

    def clear_results(self, *_):
        self.results.text = "النتائج ستظهر هنا."
        self.status.text = "الحالة: جاهز"

    def info(self, message):
        content = BoxLayout(orientation="vertical", padding=dp(12), spacing=dp(10))
        label = Label(text=message, color=WHITE, halign="right", valign="middle")
        label.bind(size=lambda inst, val: setattr(inst, "text_size", val))
        content.add_widget(label)
        close = Button(text="إغلاق", size_hint_y=None, height=dp(44),
                       background_normal="", background_color=PANEL, color=GREEN)
        content.add_widget(close)
        popup = Popup(title="مهندس الظل", content=content, size_hint=(0.88, 0.48),
                      background_color=BG, title_color=GREEN)
        close.bind(on_release=popup.dismiss)
        popup.open()

if __name__ == "__main__":
    ShadowApp().run()
